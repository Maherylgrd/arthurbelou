<?php
include('data.php');
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Produit</title>
	<style type="text/css">
		img{
			border-radius: 20px;
		}
		body{
			background-color: #41494d;
		}
		#coco{
			border:solid;
			background-color: white;
		}
		#caca{
			padding-top: 20px;
			margin-top: 50px;
			float: left;
			border:solid;
			width: 30%;
			height: 550px;
			margin-left: 40px;
			border-radius: 40px;
			background-color: white;

		}
		#cici{
			
			border:solid;
			border-radius: 20px;
			margin-top: 100px;
			background-color: white;
		}
		h1{
			font-style: monospace;
		}
		#ensamb{
			border:solid;

		}
		#ambany{
			margin-top: auto;
		}
	</style>
</head>
<body>
	<div id="coco"><center><h1>Voici nos produit</h1></center></div>
	<div id="ensamb">
	<?php for ($i=0; $i <12 ; $i++) { 
		?>
				<div id="caca"><center><img src="<?php echo $produit[$i]['image']?>"></center>
				<center><p><?php echo $produit[$i]['nom']?></p></center>
				<center><p><?php echo $produit[$i]['descri']?></p>
				<br>
				<center><p style="color: green;font-size: 20px;"><b style="color: black;">Prix : </b><?php echo $produit[$i]['prix'] ?></p></center><br>
				<center><a href="traitement.php?num=<?php echo $i ?>">AJOUTER PANIER</a></center>
				</div>
			
<?php	} 

	?>
	</div>
	
	<div id="ambany"><p><center><a href="panier.php">VOIR VOS ACHATS</a></center></p>
	<p><a href="deco.php">DECO</a></p></div>
</body>
</html>