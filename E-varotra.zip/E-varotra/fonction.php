<?php
function mijerymitovy($tab)
{
	$compt=count(tab);
	return $compt;

}
function papa($tab,$produit)
{
	$compt=count($tab);
	$kaonty=count($produit)
	for ($i=0; $i <$kaonty; $i++) { 
		$tabartif[$i]=0;
		for ($j=0; $j <$compt ; $j++) { 
			if ($i==$tab[$j]) {
				$isa[$i]++;
			}
		}
	}
	return $isa;
}
function manisa($tableau)
{
	$compt=0;
	$isa=count($tableau);
	for ($i=0; $i <$isa ; $i++) { 
		if ($tableau[$i]>0) {
			$compt++;
		}
	}
	return $compt;
}
function indiceprod($tabrehetra,$lenumray)
 {
 	$compt=count($tabrehetra);
 	$ind=0;
 	$rep=0;
 	for ($i=0; $i <$compt ; $i++) { 
		 if ($lenumray==$tabrehetra[$ind] && $lenumray==$tabrehetra[$i+1]) {
		 	$rep=0;
		 	return $rep;
		 }
		 elseif ($lenumray!=$tabrehetra[$ind] && $lenumray==$tabrehetra[$i+1]) {
		 	$rep=0;
		 	return $rep;
		 }
 	}
 } 
?>