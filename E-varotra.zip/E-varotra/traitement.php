<?php 
include('data.php');
$number=$_GET['num'];
session_start();

if (!isset($_SESSION['harona'])) {
	$_SESSION['harona']=array();
}
	$tab=$_SESSION['harona'];
	$tab[]=$number;
	$_SESSION['harona']=$tab;
	$_SESSION['isa']=count($tab);
	header('location:index.php');


?>