<?php
session_start();
include ('data.php');
include ('fonction.php');

$isage=$_SESSION['isa'];
$tableau=papa($_SESSION['harona'],$produit);
$finfor=manisa($tableau);
for ($i=0; $i <count($produit) ; $i++) { 
	if ($tableau[$i]>0) {
		
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>VOS ACHATS</title>
	<style type="text/css">
		#helo{
			float: left;
			margin-right: 200px;
			height: 400px;
			border:solid;
			margin-top: 100px;
		}
	</style>
</head>
<body>
	
	<center><h1>VOICI VOTRE PANIER</h1></center>
	<table>
	<?php 
	for ($i=0; $i <$finfor ; $i++)
	{ ?>
		
			<th>
				<td>Nom : <?php echo ?></td>
			</th>
		
<?php	} ?>
	</table>
	
</body>
</html>